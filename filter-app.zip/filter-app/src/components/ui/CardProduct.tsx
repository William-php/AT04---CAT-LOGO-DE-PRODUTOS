import Product from "@/interface/Product"
import { Image, Text, View } from "react-native"

const CardProduct = (props: Product) => {
    return (
        <View>
            <Image
                
            />
            <Text>ID: {props.id}</Text>
            <Text>Nome: {props.name}</Text>
            <Text>Quantidade: {props.qtd}</Text>
        </View>
    );
}

export default CardProduct;