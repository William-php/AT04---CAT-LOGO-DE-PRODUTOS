import { StyleSheet, TextInput, View } from "react-native"

type FilterProductProps = {    
    name: string | undefined,
    changeTextFn: (e: any) => any
}
const FilterProduct = (props: FilterProductProps) => {
    return (
        <TextInput                
            value={props.name}
            onChangeText={props.changeTextFn}
            style={styles.input}
        />        
    );
}

const styles = StyleSheet.create({
    input: {
        borderColor: "black",
        borderWidth: 1,
        padding: "10px"

    }
})

export default FilterProduct;