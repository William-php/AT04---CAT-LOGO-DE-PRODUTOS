import Product from "@/interface/Product";
import AsyncStorage from '@react-native-async-storage/async-storage';

export default class AsyncProductController {
    public static  saveProduct = async (product?: Product) => {
        try {
            const items = [
                {id: 1, name: "PC", qtd: 10}, {id: 1, name: "Celular", qtd: 11}
            ]
            const productJSONstringValue = JSON.stringify(items);
            await AsyncStorage.setItem("products", productJSONstringValue);

        } catch (error) {
            console.error("Erro ao salvar produto!");
        }
    }

    public static getProducts = async () => {
        try {
            
            const products = await AsyncStorage.getItem("products");
            if (!products) {
                throw new Error("Produtos vazio");
            }
            const productJSON = JSON.parse(products);
            return productJSON as Product[];                    
        } catch (error) {
            console.error("Erro ao buscar lista");
        }
    }
}