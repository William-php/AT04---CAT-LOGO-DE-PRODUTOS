import CardProduct from "@/components/ui/CardProduct";
import FilterProduct from "@/components/ui/FilterProduct"
import AsyncProductController from "@/controller/AsyncProductController";
import Product from "@/interface/Product";
import { useEffect, useState } from "react";
import { Button, FlatList, Text, View } from "react-native"

const ProductPage = () => {
    const [itemProductFilter, setItemProductFilter] = useState<string>("");
    const [productsInComponent, setProductsInComponent] = useState<Product[]>([]);

    useEffect(() => {
        if (productsInComponent.length === 0) {
            getProductInAsyncStorage();
        }
    }, [productsInComponent]);

    const saveProductInAsyncStorage = async () => {
        await AsyncProductController.saveProduct();
    }

    const getProductInAsyncStorage = async () => {
        if (!productsInComponent.length) {
            await saveProductInAsyncStorage();
        }
        const productsTemp = await AsyncProductController.getProducts();
        if (productsTemp) {
            setProductsInComponent(productsTemp);
        }
    }

    const handleFilter = async (itemName: string) => {
        if (!itemName) {
            const productsTemp = await  AsyncProductController.getProducts();            
            if (productsTemp) setProductsInComponent(productsTemp);
            setItemProductFilter(itemName);
            return;
        }
        filterItems(itemName);
        setItemProductFilter(itemName);

        
    }

    const renderItems = ({item}: any) => {
        return (<CardProduct 
            id={item.id}
            name={item.name}
            qtd={item.qtd}
        />);
    }

    const filterItems = (itemName: string) => {
        const test = productsInComponent.filter((item) => (item.name.includes(itemName)));        
        setProductsInComponent(test);
    }
    
    

    return (
        <View>
            <FilterProduct
                name={itemProductFilter}
                changeTextFn={handleFilter}
            />

            <Button                
                title="Salvar Item"
            />

            <FlatList
                data={productsInComponent}
                renderItem={renderItems}
                keyExtractor={item => item.id.toString()}
            />
        </View>
    );
}

export default ProductPage;