export default interface Product {
    id: number,
    name: string,
    qtd?: number,
    local?: unknown
    img?: string | undefined
}